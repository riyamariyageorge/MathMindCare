﻿
// JavaScript code to execute when the page loads
window.onload = function () {

};

function getNumber1(number) {
    debugger;
    document.getElementById('htnDrawNumber').value = number;
}



function LoadNumberImage(ncanvas, number) {

    var images = new Array();
    var canvas = document.getElementById(ncanvas);
    var ctx = canvas.getContext('2d');
    images[0] = new Image();
    images[0].src = ('../images/Numbers/' + number + '.png');
    ctx.drawImage(images[0], 0, 0);


    //var canvas = document.getElementById(ncanvas);
    //if (canvas.getContext) {
    //    var ctx = canvas.getContext('2d');
    //    //Loading of the home test image - img1
    //    var img1 = new Image();
    //    img1.src = '../images/Numbers/1.png';
    //    //drawing of the test image - img1
    //    img1.onload = function () {
    //        //draw background image
    //        ctx.drawimage(img1, 0, 0);
    //    };
    //}
}

function pasteimage(img, x, y) {
    var images = new Array();
    var canvas = document.getElementById('drcanvas');
    var ctx = canvas.getContext('2d');
    images[0] = new Image();
    images[0].src = ('../images/Numbers/' + img + '.png');
    ctx.drawImage(images[0], x, y);

    
    //// select canvas elements
    //debugger;
    //var sourceCanvas = document.getElementById("btn" + img);
    //var destCanvas = document.getElementById("drcanvas");

    ////copy canvas by DataUrl
    //var sourceImageData = sourceCanvas.toDataURL("image/png");
    //var destCanvasContext = destCanvas.getContext('2d');

    //var destinationImage = new Image;
    //destinationImage.onload = function () {
    //    destCanvasContext.drawImage(destinationImage, x, y);
    //};
    //destinationImage.src = sourceImageData;
}