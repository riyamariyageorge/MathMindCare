﻿using EmguDetection.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.Drawing;
using System.IO;

namespace EmguDetection.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
            // Load the main image
          
        }

        [HttpPost]
        public JsonResult SaveImage(string n1, string n2,string n3,string n4,string n5,string n6, string imageData)
        {

            var path = Path.GetFullPath("wwwroot");


            string fileNameWitPath = path + "\\Images\\TestImages\\" + DateTime.Now.ToString().Replace("/", "_").Replace(" ", "_").Replace(":", "") + ".png";
            using (FileStream fs = new FileStream(fileNameWitPath, FileMode.Create))
            {
                using (BinaryWriter bw = new BinaryWriter(fs))
                {
                    byte[] data = Convert.FromBase64String(imageData);
                    bw.Write(data);
                    bw.Close();
                }
            }
            //var path = Path.GetFullPath("TestImages");


            //string fileNameWitPath = path + "\\original.png";
            string fileNameTemplatePath1 = path + "\\Images\\Numbers\\" + n1 + ".png";
            string fileNameTemplatePath2 = path + "\\Images\\Numbers\\" + n2 + ".png";
            string fileNameTemplatePath3 = path + "\\Images\\Numbers\\" + n3 + ".png";
            string fileNameTemplatePath4 = path + "\\Images\\Numbers\\" + n4 + ".png";
            string fileNameTemplatePath5 = path + "\\Images\\Numbers\\" + n5 + ".png";
            string fileNameTemplatePath6 = path + "\\Images\\Numbers\\" + n6 + ".png";

            Mat mainImage = CvInvoke.Imread(fileNameWitPath, ImreadModes.Color);

            Mat templateImage1 = CvInvoke.Imread(fileNameTemplatePath1, ImreadModes.Color);
            Mat result1 = new Mat();
            CvInvoke.MatchTemplate(mainImage, templateImage1, result1, TemplateMatchingType.CcoeffNormed);
            double[] minValues1, maxValues1;
            Point[] minLocations1, maxLocations1;
            result1.MinMax(out minValues1, out maxValues1, out minLocations1, out maxLocations1);

            Mat templateImage2 = CvInvoke.Imread(fileNameTemplatePath2, ImreadModes.Color);
            Mat result2 = new Mat();
            CvInvoke.MatchTemplate(mainImage, templateImage2, result2, TemplateMatchingType.CcoeffNormed);
            double[] minValues2, maxValues2;
            Point[] minLocations2, maxLocations2;
            result2.MinMax(out minValues2, out maxValues2, out minLocations2, out maxLocations2);


            Mat templateImage3 = CvInvoke.Imread(fileNameTemplatePath3, ImreadModes.Color);
            Mat result3 = new Mat();
            CvInvoke.MatchTemplate(mainImage, templateImage3, result3, TemplateMatchingType.CcoeffNormed);
            double[] minValues3, maxValues3;
            Point[] minLocations3, maxLocations3;
            result3.MinMax(out minValues3, out maxValues3, out minLocations3, out maxLocations3);

            Mat templateImage4 = CvInvoke.Imread(fileNameTemplatePath4, ImreadModes.Color);
            Mat result4 = new Mat();
            CvInvoke.MatchTemplate(mainImage, templateImage4, result4, TemplateMatchingType.CcoeffNormed);
            double[] minValues4, maxValues4;
            Point[] minLocations4, maxLocations4;
            result4.MinMax(out minValues4, out maxValues4, out minLocations4, out maxLocations4);

            if (minLocations4[0].X <= minLocations2[0].X)
            {
                for (int i = 0; i < maxLocations4.Length; i++)
                {
                    Rectangle rect = new Rectangle(maxLocations4[i], templateImage4.Size);
                    CvInvoke.Rectangle(mainImage, rect, new MCvScalar(0, 0, 255), 2);
                }
            }


            CvInvoke.Imwrite(fileNameWitPath, mainImage);
            // CvInvoke.Imshow("Result", mainImage);
            // CvInvoke.WaitKey(0);


            string filename = System.IO.Path.GetFileName(fileNameWitPath);

            return Json(new { Status = filename, Record = "", Message = fileNameWitPath });
        }
        [HttpPost]
        public JsonResult SaveImageOld(string name1, string name2, string imageData)
        {

            var path = Path.GetFullPath("wwwroot");


            string fileNameWitPath = path + "\\Images\\TestImages\\" + DateTime.Now.ToString().Replace("/", "_").Replace(" ", "_").Replace(":", "") + ".png";
            using (FileStream fs = new FileStream(fileNameWitPath, FileMode.Create))
            {
                using (BinaryWriter bw = new BinaryWriter(fs))
                {
                    byte[] data = Convert.FromBase64String(imageData);
                    bw.Write(data);
                    bw.Close();
                }
            }
            //var path = Path.GetFullPath("TestImages");


            //string fileNameWitPath = path + "\\original.png";
            string fileNameTemplatePath = path + "\\Images\\Numbers\\6.png";

            Mat mainImage = CvInvoke.Imread(fileNameWitPath, ImreadModes.Color);

            Mat templateImage = CvInvoke.Imread(fileNameTemplatePath, ImreadModes.Color);

            Mat result = new Mat();
            CvInvoke.MatchTemplate(mainImage, templateImage, result, TemplateMatchingType.CcoeffNormed);

            double[] minValues, maxValues;
            Point[] minLocations, maxLocations;
            result.MinMax(out minValues, out maxValues, out minLocations, out maxLocations);

            for (int i = 0; i < maxLocations.Length; i++)
            {
                Rectangle rect = new Rectangle(maxLocations[i], templateImage.Size);
                CvInvoke.Rectangle(mainImage, rect, new MCvScalar(0, 0, 255), 2);
            }

            CvInvoke.Imwrite(fileNameWitPath, mainImage);
            // CvInvoke.Imshow("Result", mainImage);
            // CvInvoke.WaitKey(0);


            string filename = System.IO.Path.GetFileName(fileNameWitPath);

            return Json(new { Status = filename, Record = "", Message = fileNameWitPath });
        }
        public IActionResult Canvas()
        {
           
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
